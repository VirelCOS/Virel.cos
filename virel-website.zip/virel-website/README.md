# Virel Website

Static launch website for Virel / Honor Code / Code of Silence collection.

## GitHub Pages Setup

1. Create a new GitHub repository named `virel-website`.
2. Upload `index.html`, `style.css`, `script.js`, and this `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/root**.
6. Save. GitHub will publish the site.

## Customization

- Replace the Formspree link in `index.html` with your own form endpoint.
- Replace placeholder product cards with real mockup images when ready.
- Edit product copy, sizing, and colorways inside `index.html`.
